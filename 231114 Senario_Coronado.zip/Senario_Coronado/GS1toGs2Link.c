stk.v.12.0
WrittenBy    STK_v12.6.0

BEGIN Chain

    Name		 GS1toGs2Link
    BEGIN Definition
        Object		 Place/Gs1Coronado/Transmitter/Gs1_Xmt
        Object		 Aircraft/Relay1Air/Receiver/Relay_RcvfromGS1
        Object		 Aircraft/Relay1Air/Transmitter/Relay_XmttoGs2
        Object		 Place/Gs2YPG/Receiver/Gs2_Rcv
        Type		 Chain
        FromOperator		 Or
        FromOrder		 1
        ToOperator		 Or
        ToOrder		 1
        Recompute		 Yes
        IntervalType		 0
        ComputeIntervalStart		 0
        ComputeIntervalStop		 7200
        ComputeIntervalPtr		
        BEGIN EVENTINTERVAL
            BEGIN Interval
                Start		 24 Jan 2024 20:00:00.000000000
                Stop		 24 Jan 2024 22:00:00.000000000
            END Interval
            IntervalState		 Explicit
        END EVENTINTERVAL

        ConstConstraintsByStrands		 Yes
        UseSaveIntervalFile		 No
        UseMinAngle		 No
        UseMaxAngle		 No
        UseMinLinkTime		 No
        LTDelayCriterion		 2
        TimeConvergence		 0.005
        AbsValueConvergence		 1e-14
        RelValueConvergence		 1e-08
        MaxTimeStep		 360
        MinTimeStep		 0.01
        UseLightTimeDelay		 Yes
        DetectEventsUsingSamplesOnly		 No
        UseLoadIntervalFile		 No
        AllowSameInstInStrands		 Yes
        KeepStrandsWithNoIntvls		 No
        BEGIN StrandObjIndexes
            STKInst		 Place/Gs1Coronado/Transmitter/Gs1_Xmt
            STKInst		 Aircraft/Relay1Air/Receiver/Relay_RcvfromGS1
            STKInst		 Aircraft/Relay1Air/Transmitter/Relay_XmttoGs2
            STKInst		 Place/Gs2YPG/Receiver/Gs2_Rcv
        END StrandObjIndexes

        SaveMode		 1
        BEGIN StrandAccessesByIndex
            Strand		 0 1 2 3
            Start		  0.0000000000000000e+00
            Stop		  6.4577049002669364e+03
        END StrandAccessesByIndex


    END Definition

    BEGIN Extensions

        BEGIN ExternData
        END ExternData

        BEGIN ADFFileData
        END ADFFileData

        BEGIN Desc
        END Desc

        BEGIN Crdn
        END Crdn

        BEGIN Graphics

            BEGIN Attributes

                StaticColor		 #ffffff
                AnimationColor		 #00ff00
                AnimationLineWidth		 2
                StaticLineWidth		 3

            END Attributes

            BEGIN Graphics
                ShowGfx		 On
                ShowStatic		 Off
                ShowAnimationHighlight		 On
                ShowAnimationLine		 On
                ShowLinkDirection		 Off
            END Graphics
        END Graphics

        BEGIN VO
        END VO

    END Extensions

END Chain

