stk.v.12.0
WrittenBy    STK_v12.6.0

BEGIN Chain

    Name		 GS1toGs2Link
    BEGIN Definition
        Object		 Place/Gs1_Diablo/Transmitter/Gs1_Xmt
        Object		 Aircraft/RelayAirMercd/Receiver/Relay_RcvfromGs1new
        Object		 Aircraft/RelayAirMercd/Transmitter/Relay_XmttoGs2new
        Object		 Place/Gs2_NPS/Receiver/Gs2_Rcv
        Type		 Chain
        FromOperator		 Or
        FromOrder		 1
        ToOperator		 Or
        ToOrder		 1
        Recompute		 Yes
        IntervalType		 0
        ComputeIntervalStart		 0
        ComputeIntervalStop		 8100
        ComputeIntervalPtr		
        BEGIN EVENTINTERVAL
            BEGIN Interval
                Start		 15 May 2024 19:45:00.000000000
                Stop		 15 May 2024 22:00:00.000000000
            END Interval
            IntervalState		 Explicit
        END EVENTINTERVAL

        ConstConstraintsByStrands		 Yes
        UseSaveIntervalFile		 No
        UseMinAngle		 No
        UseMaxAngle		 No
        UseMinLinkTime		 No
        LTDelayCriterion		 2
        TimeConvergence		 0.005
        AbsValueConvergence		 1e-14
        RelValueConvergence		 1e-08
        MaxTimeStep		 360
        MinTimeStep		 0.01
        UseLightTimeDelay		 Yes
        DetectEventsUsingSamplesOnly		 No
        UseLoadIntervalFile		 No
        AllowSameInstInStrands		 Yes
        KeepStrandsWithNoIntvls		 No
        BEGIN StrandObjIndexes
            STKInst		 Place/Gs1_Diablo/Transmitter/Gs1_Xmt
            STKInst		 Aircraft/RelayAirMercd/Receiver/Relay_RcvfromGs1new
            STKInst		 Aircraft/RelayAirMercd/Transmitter/Relay_XmttoGs2new
            STKInst		 Place/Gs2_NPS/Receiver/Gs2_Rcv
        END StrandObjIndexes

        SaveMode		 1
        BEGIN StrandAccessesByIndex
            Strand		 0 1 2 3
            Start		  1.2648439999999973e+03
            Stop		  4.6636830000000045e+03
        END StrandAccessesByIndex


    END Definition

    BEGIN Extensions

        BEGIN ExternData
        END ExternData

        BEGIN ADFFileData
        END ADFFileData

        BEGIN Desc
        END Desc

        BEGIN Crdn
        END Crdn

        BEGIN Graphics

            BEGIN Attributes

                StaticColor		 #ffffff
                AnimationColor		 #ff0000
                AnimationLineWidth		 2
                StaticLineWidth		 3

            END Attributes

            BEGIN Graphics
                ShowGfx		 On
                ShowStatic		 Off
                ShowAnimationHighlight		 Off
                ShowAnimationLine		 Off
                ShowLinkDirection		 Off
            END Graphics
        END Graphics

        BEGIN VO
        END VO

    END Extensions

END Chain

